# BakraDEMaterialShell Installation

## Requirements

- Wayland compositor (niri or Hyprland recommended)
- Quickshell framework
- Qt6

## Installation Steps

1. **Install quickshell assets:**
   ```bash
   mkdir -p ~/.config/quickshell
   cp -r dms ~/.config/quickshell/
   ```

2. **Install the DMS CLI binaries:**
   ```bash
   sudo install -m 755 bin/dms /usr/local/bin/dms
   ```

3. **Install shell completions (optional):**
   ```bash
   # Bash
   sudo install -m 644 completions/completion.bash /usr/share/bash-completion/completions/dms

   # Fish
   sudo install -m 644 completions/completion.fish /usr/share/fish/vendor_completions.d/dms.fish

   # Zsh
   sudo install -m 644 completions/completion.zsh /usr/share/zsh/site-functions/_dms
   ```

4. **Start the shell:**
   ```bash
   dms run
   ```

## Configuration

- Settings are stored in `~/.config/BakraDEMaterialShell/settings.json`
- Plugins go in `~/.config/BakraDEMaterialShell/plugins/`
- See the documentation in the `dms/` directory for more details

## Troubleshooting

- Run with verbose output: `DMS_LOG_LEVEL=debug dms run`
- Ensure all dependencies are installed
