# BakraDEMaterialShell Installation

## Requirements

- Wayland compositor (niri or Hyprland recommended)
- Quickshell framework
- Qt6

## Installation Steps

1. **Install quickshell assets:**
   ```bash
   mkdir -p ~/.config/quickshell
   cp -r bms ~/.config/quickshell/
   ```

2. **Install the BMS CLI binaries:**
   ```bash
   sudo install -m 755 bin/bms /usr/local/bin/bms
   ```

3. **Install shell completions (optional):**
   ```bash
   # Bash
   sudo install -m 644 completions/completion.bash /usr/share/bash-completion/completions/bms

   # Fish
   sudo install -m 644 completions/completion.fish /usr/share/fish/vendor_completions.d/bms.fish

   # Zsh
   sudo install -m 644 completions/completion.zsh /usr/share/zsh/site-functions/_bms
   ```

4. **Start the shell:**
   ```bash
   bms run
   ```

## Configuration

- Settings are stored in `~/.config/BakraDEMaterialShell/settings.json`
- Plugins go in `~/.config/BakraDEMaterialShell/plugins/`
- See the documentation in the `bms/` directory for more details

## Troubleshooting

- Run with verbose output: `BMS_LOG_LEVEL=debug bms run`
- Ensure all dependencies are installed
