.pragma library

.import "./SettingsSpec.js" as SpecModule

function parse(root, jsonObj) {
    var SPEC = SpecModule.SPEC;
    for (var k in SPEC) {
        if (k === "pluginSettings") continue;
        var spec = SPEC[k];
        root[k] = spec.def;
    }

    if (!jsonObj) return;

    for (var k in jsonObj) {
        if (!SPEC[k]) continue;
        if (k === "pluginSettings") continue;
        var raw = jsonObj[k];
        var spec = SPEC[k];
        var coerce = spec.coerce;
        root[k] = coerce ? (coerce(raw) !== undefined ? coerce(raw) : root[k]) : raw;
    }
}

function toJson(root) {
    var SPEC = SpecModule.SPEC;
    var out = {};
    for (var k in SPEC) {
        if (SPEC[k].persist === false) continue;
        if (k === "pluginSettings") continue;
        out[k] = root[k];
    }
    out.configVersion = root.settingsConfigVersion;
    return out;
}

function migrateToVersion(obj, targetVersion) {
    if (!obj) return null;

    var settings = JSON.parse(JSON.stringify(obj));
    var currentVersion = settings.configVersion || 0;

    if (currentVersion >= targetVersion) {
        return null;
    }

    if (currentVersion < 2) {
        console.info("Migrating settings from version", currentVersion, "to version 2");

        if (settings.barConfigs === undefined) {
            var position = 0;
            if (settings.bakraDEBarAtBottom !== undefined || settings.topBarAtBottom !== undefined) {
                var atBottom = settings.bakraDEBarAtBottom !== undefined ? settings.bakraDEBarAtBottom : settings.topBarAtBottom;
                position = atBottom ? 1 : 0;
            } else if (settings.bakraDEBarPosition !== undefined) {
                position = settings.bakraDEBarPosition;
            }

            var defaultConfig = {
                id: "default",
                name: "Main Bar",
                enabled: true,
                position: position,
                screenPreferences: ["all"],
                showOnLastDisplay: true,
                leftWidgets: settings.bakraDEBarLeftWidgets || ["launcherButton", "workspaceSwitcher", "focusedWindow"],
                centerWidgets: settings.bakraDEBarCenterWidgets || ["music", "clock", "weather"],
                rightWidgets: settings.bakraDEBarRightWidgets || ["systemTray", "clipboard", "cpuUsage", "memUsage", "notificationButton", "battery", "controlCenterButton"],
                spacing: settings.bakraDEBarSpacing !== undefined ? settings.bakraDEBarSpacing : 4,
                innerPadding: settings.bakraDEBarInnerPadding !== undefined ? settings.bakraDEBarInnerPadding : 4,
                bottomGap: settings.bakraDEBarBottomGap !== undefined ? settings.bakraDEBarBottomGap : 0,
                transparency: settings.bakraDEBarTransparency !== undefined ? settings.bakraDEBarTransparency : 1.0,
                widgetTransparency: settings.bakraDEBarWidgetTransparency !== undefined ? settings.bakraDEBarWidgetTransparency : 1.0,
                squareCorners: settings.bakraDEBarSquareCorners !== undefined ? settings.bakraDEBarSquareCorners : false,
                noBackground: settings.bakraDEBarNoBackground !== undefined ? settings.bakraDEBarNoBackground : false,
                gothCornersEnabled: settings.bakraDEBarGothCornersEnabled !== undefined ? settings.bakraDEBarGothCornersEnabled : false,
                gothCornerRadiusOverride: settings.bakraDEBarGothCornerRadiusOverride !== undefined ? settings.bakraDEBarGothCornerRadiusOverride : false,
                gothCornerRadiusValue: settings.bakraDEBarGothCornerRadiusValue !== undefined ? settings.bakraDEBarGothCornerRadiusValue : 12,
                borderEnabled: settings.bakraDEBarBorderEnabled !== undefined ? settings.bakraDEBarBorderEnabled : false,
                borderColor: settings.bakraDEBarBorderColor || "surfaceText",
                borderOpacity: settings.bakraDEBarBorderOpacity !== undefined ? settings.bakraDEBarBorderOpacity : 1.0,
                borderThickness: settings.bakraDEBarBorderThickness !== undefined ? settings.bakraDEBarBorderThickness : 1,
                fontScale: settings.bakraDEBarFontScale !== undefined ? settings.bakraDEBarFontScale : 1.0,
                autoHide: settings.bakraDEBarAutoHide !== undefined ? settings.bakraDEBarAutoHide : false,
                autoHideDelay: settings.bakraDEBarAutoHideDelay !== undefined ? settings.bakraDEBarAutoHideDelay : 250,
                openOnOverview: settings.bakraDEBarOpenOnOverview !== undefined ? settings.bakraDEBarOpenOnOverview : false,
                visible: settings.bakraDEBarVisible !== undefined ? settings.bakraDEBarVisible : true,
                popupGapsAuto: settings.popupGapsAuto !== undefined ? settings.popupGapsAuto : true,
                popupGapsManual: settings.popupGapsManual !== undefined ? settings.popupGapsManual : 4
            };

            settings.barConfigs = [defaultConfig];

            var legacyKeys = [
                "bakraDEBarLeftWidgets", "bakraDEBarCenterWidgets", "bakraDEBarRightWidgets",
                "bakraDEBarWidgetOrder", "bakraDEBarAutoHide", "bakraDEBarAutoHideDelay",
                "bakraDEBarOpenOnOverview", "bakraDEBarVisible", "bakraDEBarSpacing",
                "bakraDEBarBottomGap", "bakraDEBarInnerPadding", "bakraDEBarPosition",
                "bakraDEBarSquareCorners", "bakraDEBarNoBackground", "bakraDEBarGothCornersEnabled",
                "bakraDEBarGothCornerRadiusOverride", "bakraDEBarGothCornerRadiusValue",
                "bakraDEBarBorderEnabled", "bakraDEBarBorderColor", "bakraDEBarBorderOpacity",
                "bakraDEBarBorderThickness", "popupGapsAuto", "popupGapsManual",
                "bakraDEBarAtBottom", "topBarAtBottom", "bakraDEBarTransparency", "bakraDEBarWidgetTransparency"
            ];

            for (var i = 0; i < legacyKeys.length; i++) {
                delete settings[legacyKeys[i]];
            }

            console.info("Migrated single bar settings to barConfigs");
        }

        settings.configVersion = 2;
    }

    return settings;
}

function cleanup(fileText) {
    var getValidKeys = SpecModule.getValidKeys;
    if (!fileText || !fileText.trim()) return;

    try {
        var settings = JSON.parse(fileText);
        var validKeys = getValidKeys();
        var needsSave = false;

        for (var key in settings) {
            if (validKeys.indexOf(key) < 0) {
                delete settings[key];
                needsSave = true;
            }
        }

        return needsSave ? JSON.stringify(settings, null, 2) : null;
    } catch (e) {
        console.warn("SettingsData: Failed to cleanup unused keys:", e.message);
        return null;
    }
}
