# Dynamic Base16 BakraDEShell Theme

A VSCode theme for [BakraDEMaterialShell](https://github.com/EverydayCodeAlchemy/BakraDEMaterialShellGit).

## How It Works

1. Install this extension
2. Select one of the "Dynamic Base16 BakraDEShell" themes in VSCode
3. BakraDEMaterialShell automatically updates the theme files when you change themes.

The theme files are located in your VSCode extensions directory and are updated by matugen when generating new colors.

## Themes

- **Dynamic Base16 BakraDEShell** - Follows your current light/dark mode
- **Dynamic Base16 BakraDEShell (Dark)** - Always dark variant
- **Dynamic Base16 BakraDEShell (Light)** - Always light variant
